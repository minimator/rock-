
<link rel="stylesheet" href="../../css/navbar.css">

<section id="content">
        <nav>
        <a href="../../index.php" class="home-link">
         Back
            </a>
            <span class="text">
            <h3>Mahan Nepali Driving School</h3>

            </span>
            <a href="#" class="profile">
                <img src="../../assets/logoBlack.png">
            </a>
        </nav>
        
    </section>
