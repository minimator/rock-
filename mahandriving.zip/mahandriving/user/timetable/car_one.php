<?php
$conn = mysqli_connect("localhost", "root", "", "mahandriving");
?>

<style>
    .active-slot {
        background-color: #c8e6c9; /* Light green background for active slots */
        color: #388e3c; /* Dark green text for active slots */
        text-align: center;
        padding: 10px;
        border: 1px solid #388e3c; /* Dark green border */
    }

    .empty-slot {
        background-color: #ffcdd2; /* Light red background for empty slots */
        color: #d32f2f; /* Dark red text for empty slots */
        text-align: center;
        padding: 10px;
        border: 1px solid #d32f2f; /* Dark red border */
    }
</style>

<?php

date_default_timezone_set('Asia/Kolkata');
$current_timestamp_by_mktime = mktime(date("m"), date("d"), date("Y"));
$currentDate = date("Y-m-d", $current_timestamp_by_mktime);

$check = "SELECT * FROM car_one WHERE status = 'active'";
$result = mysqli_query($conn, $check);
// echo $currentDate."<br>";
if (!$result) {
    die("Error executing query: " . mysqli_error($conn));
}

if (mysqli_num_rows($result) > 0) {
    // Loop through each row
    while ($row = mysqli_fetch_assoc($result)) {
        $endDate = (string) $row['end_date'];
        // echo $endDate."<br>";

        if ($endDate < $currentDate) {
            $id = $row['id'];

            $update = "UPDATE car_one SET name='', phone='', vehicle='', trainer='',  start_date='', end_date='', status='empty' WHERE id = '$id'";
            $updateResult = mysqli_query($conn, $update);

            if (!$updateResult) {
                die("Error updating row: " . mysqli_error($conn));
            } else {
                echo "Rows updated successfully. i10";
            }
        }
    }


} else {
    echo "No rows to update. i10";
}

?>

<?php



if (isset($_GET['car'])) {
    if ($_GET['car'] == "i10") {
        ?>

        <div class="title">Hyundai i10 Time-Table <i class='bx bx-table'></i></div>

        <table>
            <thead>
                <tr>
                    <th>Timeslots</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Vehicle</th>
                    <th>Trainer</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Status</th>
                  
                </tr>
            </thead>
            <tbody>

                <?php


                $select = "SELECT * FROM car_one";
                $result = $conn->query($select);
                if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {

                        ?>

                        <tr>
                            <td>
                                <?php echo $row['timeslots']; ?>
                            </td>
                            <td>
                                <?php echo $row['name']; ?>
                            </td>
                            <td>
                                <?php echo $row['phone']; ?>
                            </td>
                            <td>
                                <?php echo $row['vehicle']; ?>
                            </td>
                            <td>
                                <?php echo $row['trainer']; ?>
                            </td>
                            <td>
                                <?php echo $row['start_date']; ?>
                            </td>
                            <td>
                                <?php echo $row['end_date']; ?>
                            </td>
                            
                            <td class="<?php echo ($row['status'] == 'active') ? 'active-slot' : 'empty-slot'; ?>">
    <?php if ($row['status'] == 'active'): ?>
        Active
    <?php else: ?>
        Empty
    <?php endif; ?>
</td>

                        </tr>

                        <?php

                    }
                }

                ?>

            </tbody>
        </table>

        <?php
    }
} else {
    exit();
}

?>